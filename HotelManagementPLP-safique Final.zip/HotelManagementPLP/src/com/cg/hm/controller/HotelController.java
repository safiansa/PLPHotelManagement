package com.cg.hm.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.cg.hm.dto.Admin;
import com.cg.hm.dto.BookingDetail;
import com.cg.hm.dto.Hotel;
import com.cg.hm.dto.RoomDetail;
import com.cg.hm.dto.UserDetail;
import com.cg.hm.exception.HotelManagementException;
import com.cg.hm.service.HotelService;

/**
 * controller
 * 
 * @author rohitaku
 *
 */
@Controller
@SessionAttributes("admin")
public class HotelController {
	@Autowired
	HotelService hotelService;

	/**
	 * Redirects to Home.jsp
	 * 
	 * @return
	 */
	@RequestMapping("/home.htm")
	public String redirectToHome() {
		return "Home";
	}

	/**
	 * Redirects to Admin.jsp
	 * 
	 * @return
	 */
	@RequestMapping("/admin.htm")
	public String redirectToAdmin() {
		return "Admin";
	}

	/**
	 * Redirects to Login.jsp
	 * 
	 * @return
	 */
	@RequestMapping("/login.htm")
	public String login(Model model) {
		model.addAttribute("admin", new Admin());
		return "Login";
	}

	/**
	 * Validates Login Credentials
	 * 
	 * @param id
	 *            : Login ID
	 * @param password
	 *            :Login Password
	 * @param model
	 *            :Contains Invalid Login Message
	 * @return
	 */
	@RequestMapping(value="/checkLogin.htm",method = RequestMethod.POST)
	public String checkLogin(@ModelAttribute("admin") Admin admin, Model model,BindingResult resultl) {
		if (Constant.ADMINID.equals(admin.getId()) && Constant.ADMINPASS.equals(admin.getPassword()))
			return "Admin";
		model.addAttribute("message", Constant.iIP);
		model.addAttribute("admin", new Admin());
		return "Login";
	}
	
	/**
	 * 
	 * @param model
	 * @param status
	 * @return
	 */
	@RequestMapping("/logout.htm")
	public String logout(Model model,SessionStatus status)
	{
		status.setComplete();
		return "Home";
	}
	/**
	 * Redirects to addHotel.jsp
	 * 
	 * @param model
	 *            : Contains Empty Hotel Object
	 * @return
	 */
	@RequestMapping("/addHotel.htm")
	public String addHotel(Model model) {
		Hotel hotel = new Hotel();
		model.addAttribute("hotel", hotel);
		return "addHotel";
	}

	/**
	 * Adds Hotel to DataBase and Redirects to Admin.jsp
	 * 
	 * @param model
	 *            : Contains addHotel Success Message
	 * @param hotel
	 *            : Hotel Object to be Added
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "/addHotelImpl.htm", method = RequestMethod.POST)
	public String addHotelImpl(Model model,
			@ModelAttribute("hotel") @Valid Hotel hotel, BindingResult result) {
		try {
			if (result.hasErrors())
				return "addHotel";
			hotelService.addHotel(hotel);
			model.addAttribute("message", Constant.hAS);
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Admin";
	}

	/**
	 * Redirects to addRoom.jsp
	 * 
	 * @param hotelId
	 *            : Hotel ID of Room
	 * @param model
	 *            : Contains Hotel List and Hotel Id in which Room is to be
	 *            Added
	 * @param model2
	 *            : Contains Empty Room Object and Room Type List
	 * @return
	 */
	@RequestMapping("/addRoom.htm")
	public String addRoom(@RequestParam("hotelId") int hotelId, Model model,
			Model model2) {
		List<Hotel> list = null;
		try {
			list = hotelService.viewAllHotels();
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// if (list.isEmpty())
		// list = null;
		model2.addAttribute("list", list);
		model2.addAttribute("hotelId", hotelId);
		RoomDetail room = new RoomDetail();
		model.addAttribute("room", room);
		model.addAttribute("roomTypeList", Constant.dropDownList);
		return "addRoom";
	}

	/**
	 * Adds Room to DataBase
	 * 
	 * @param hotelId
	 *            :Hotel ID of Room
	 * @param model
	 *            :Contains addRoom Success Message and Room Type List
	 * @param model2
	 *            :Contains Hotel List and Hotel ID in which Room is to be Added
	 * @param room
	 *            :Room Object Which is to be Added
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "/addRoomImpl.htm", method = RequestMethod.POST)
	public String addRoomImpl(@RequestParam("hotelId") int hotelId,
			Model model, Model model2,
			@ModelAttribute("room") @Valid RoomDetail room, BindingResult result) {
		try {
			if (result.hasErrors()) {
				List<Hotel> list = null;
				list = hotelService.viewAllHotels();
				if (list.isEmpty())
					list = null;
				model2.addAttribute("list", list);
				model2.addAttribute("hotelId", hotelId);
				model.addAttribute("room", room);
				model.addAttribute("roomTypeList", Constant.dropDownList);
				return "addRoom";
			}
			hotelService.addRoom(room);
			model.addAttribute("message", Constant.rAS);
		} catch (HotelManagementException e) {
			System.out.println("Exception Put Details Properly");
		}
		return "Admin";
	}

	/**
	 * Retrieves List of Hotels
	 * 
	 * @param model
	 *            : Contains List of Hotels
	 * @return
	 */
	@RequestMapping("/viewHotels.htm")
	public String viewHotels(Model model) {
		List<Hotel> list = null;
		try {
			list = hotelService.viewAllHotels();
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// if (list.isEmpty())
		// list = null;
		model.addAttribute("hotelId", 0);
		model.addAttribute("list", list);
		return "HotelList";
	}

	/**
	 * Retrieve List of Rooms for a Particular Hotel
	 * 
	 * @param hotelId
	 *            : Hotel ID For Retrieving Room List
	 * @param model
	 *            :Contains Hotel List and Room List
	 * @return
	 */
	@RequestMapping("/viewRoom.htm")
	public String viewRoom(@RequestParam("hotelId") int hotelId, Model model) {
		List<Hotel> list = null;
		try {
			list = hotelService.viewAllHotels();
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("list", list);
		String msg = new String("Rooms in Hotel with Hotel ID: " + hotelId);
		List<RoomDetail> list2 = null;
		try {
			list2 = hotelService.getRoomByHotelId(hotelId);
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (list2.isEmpty()) {
			list2 = null;
			model.addAttribute("message2", Constant.nRA);
		}
		model.addAttribute("list2", list2);
		model.addAttribute("message", msg);
		return "HotelList";
	}

	/**
	 * Retrieves Room List and Redirects to deleteRoom.jsp
	 * 
	 * @param model
	 *            : Contains List of Hotels
	 * @return
	 */
	@RequestMapping("/deleteRoom.htm")
	public String deleteRoom(Model model) {
		List<RoomDetail> list = null;
		try {
			list = hotelService.viewAllRooms();
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (list.isEmpty())
			list = null;
		model.addAttribute("list", list);
		return "deleteRoom";
	}

	/**
	 * Confirms Delete Room Operation
	 * 
	 * @param roomId
	 *            : Room ID of Room which is to be Deleted
	 * @param model
	 *            : Contains List of Rooms
	 * @param model2
	 *            : Contains Room Details which is to be Deleted
	 * @return
	 */
	@RequestMapping("/deleteRoomConfirm.htm")
	public String deleteRoomConfirm(@RequestParam("hiddenRoomId") int roomId,
			Model model, Model model2) {
		List<RoomDetail> list = null;
		try {
			list = hotelService.viewAllRooms();
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("list", list);
		RoomDetail room = null;
		try {
			room = hotelService.getRoomById(roomId);
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model2.addAttribute("room", room);
		return "deleteRoom";
	}

	/**
	 * Deletes Room from DataBase
	 * 
	 * @param roomId
	 *            :Room ID of Room which is to be Deleted
	 * @param model
	 *            : Contains Successful Deletion Message
	 * @return
	 */
	@RequestMapping("/deleteRoomImpl.htm")
	public String deleteRoomImpl(@RequestParam("hiddenRoomId") int roomId,
			Model model) {
		try {
			hotelService.deleteRoom(roomId);
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("message", Constant.rDS);
		return "Admin";
	}

	/**
	 * Retrieves List of Hotels and Redirects to deleteHotel.jsp
	 * 
	 * @param model
	 *            : Contains List of Hotels
	 * @return
	 */
	@RequestMapping("/deleteHotel.htm")
	public String deleteHotel(Model model) {
		List<Hotel> list = null;
		try {
			list = hotelService.viewAllHotels();
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (list.isEmpty())
			list = null;
		model.addAttribute("list", list);
		return "deleteHotel";
	}

	/**
	 * Confirms Deletion Operation
	 * 
	 * @param hotelId
	 *            : Hotel ID of Hotel which is to be Deleted
	 * @param model
	 *            : Contains List of Hotels
	 * @param model2
	 *            : Contains Details of Hotel which is to be Deleted
	 * @return
	 */
	@RequestMapping("/deleteHotelConfirm.htm")
	public String deleteHotelConfirm(
			@RequestParam("hiddenHotelId") int hotelId, Model model,
			Model model2) {
		List<Hotel> list = null;
		try {
			list = hotelService.viewAllHotels();
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("list", list);
		Hotel hotel = null;
		try {
			hotel = hotelService.getHotelById(hotelId);
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model2.addAttribute("hotel", hotel);
		return "deleteHotel";
	}

	/**
	 * Deletes Hotel from DataBase
	 * 
	 * @param hotelId
	 *            : Hotel ID of Hotel which is to be Deleted
	 * @param model
	 *            : Contains Successful Deletion Message
	 * @return
	 */
	@RequestMapping("/deleteHotelImpl.htm")
	public String deleteHotelImpl(@RequestParam("hiddenHotelId") int hotelId,
			Model model) {
		try {
			hotelService.deleteHotel(hotelId);
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("message", Constant.hDS);
		return "Admin";
	}

	/**
	 * Retrieves List of Hotels and Details of Hotel which is to be Modified
	 * 
	 * @param hotelId
	 *            : Hotel ID of Hotel which is to be Modified
	 * @param model
	 *            : Contains List of Hotels and Details of Hotel which is to be
	 *            Modified
	 * @return
	 */
	@RequestMapping("/modifyHotel.htm")
	public String modifyHotel(@RequestParam("hotelId") int hotelId, Model model) {
		List<Hotel> list = null;
		try {
			list = hotelService.viewAllHotels();
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Hotel hotel = new Hotel();
		if (hotelId != 0)
			try {
				hotel = hotelService.getHotelById(hotelId);
			} catch (HotelManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		model.addAttribute("hotel", hotel);
		if (list.isEmpty())
			list = null;
		model.addAttribute("hotelId", hotelId);
		model.addAttribute("list", list);
		return "modifyHotel";
	}

	/**
	 * Modifies Hotel Details in DataBase
	 * 
	 * @param hotelId
	 *            : Hotel ID of Hotel which is to be Modified
	 * @param model
	 *            : Contains List of Hotels and Successful Modification Message
	 * @param hotel
	 *            : Hotel Object which is to be Modified
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "/modifyHotelImpl.htm", method = RequestMethod.POST)
	public String modifyHotelImpl(@RequestParam("hotelId") int hotelId,
			Model model, @ModelAttribute("hotel") @Valid Hotel hotel,
			BindingResult result) {
		if (result.hasErrors()) {

			List<Hotel> list = null;
			try {
				list = hotelService.viewAllHotels();
			} catch (HotelManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			model.addAttribute("hotel", hotel);
			if (list.isEmpty())
				list = null;
			model.addAttribute("hotelId", hotelId);
			model.addAttribute("list", list);
			return "modifyHotel";
		}
		try {
			hotelService.updateHotel(hotel);
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("message", Constant.hMS);
		return "Admin";
	}

	/**
	 * Retrieves List of Rooms and Redirects to modifyRoom.jsp
	 * 
	 * @param roomId
	 *            : Room ID of Room which is to be Modified
	 * @param model
	 *            : Contains List of Rooms and Details of Rooms which is to be
	 *            Modified
	 * @return
	 */
	@RequestMapping("/modifyRoom.htm")
	public String modifyRoom(@RequestParam("roomId") int roomId, Model model) {
		List<RoomDetail> list = null;
		try {
			list = hotelService.viewAllRooms();
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (list.isEmpty())
			list = null;
		RoomDetail room = new RoomDetail();
		if (roomId != 0)
			try {
				room = hotelService.getRoomById(roomId);
			} catch (HotelManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		model.addAttribute("room", room);
		model.addAttribute("roomId", roomId);
		model.addAttribute("list", list);
		model.addAttribute("roomTypeList", Constant.dropDownList);

		return "modifyRoom";
	}

	/**
	 * Modifies Room Details in DataBase
	 * 
	 * @param roomId
	 *            : Room ID of Room which is to be Modified
	 * @param model
	 *            : Contains List of Rooms and Details of Room which is to be
	 *            Modified
	 * @param room
	 *            :Room Object which is to be Modified
	 * @param result
	 * @return
	 */
	@RequestMapping(value = "/modifyRoomImpl.htm", method = RequestMethod.POST)
	public String modifyRoomImpl(@RequestParam("roomId") int roomId,
			Model model, @ModelAttribute("room") @Valid RoomDetail room,
			BindingResult result) {
		if (result.hasErrors()) {
			List<RoomDetail> list = null;
			try {
				list = hotelService.viewAllRooms();
			} catch (HotelManagementException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (list.isEmpty())
				list = null;
			model.addAttribute("room", room);
			model.addAttribute("roomId", roomId);
			model.addAttribute("list", list);
			model.addAttribute("roomTypeList", Constant.dropDownList);
			return "modifyRoom";
		}
		try {
			hotelService.updateRoom(room);
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("message", Constant.rMS);
		return "Admin";
	}

	/**
	 * Retrieves Booking Details for Today
	 * 
	 * @param model
	 *            : Contains List of Booking Details for Today
	 * @return
	 */
	@RequestMapping("/viewBookingsOnDate.htm")
	public String viewBookingsOnDate(Model model) {
		LocalDate today = LocalDate.now();
		Date date = Date.valueOf(today);
		List<BookingDetail> list = null;
		try {
			list = hotelService.viewBookingDetailsFromDate(date);
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (list.isEmpty())
			list = null;
		model.addAttribute("message", "Today");
		model.addAttribute("list", list);
		return "BookingDetailsByDate";
	}

	/**
	 * Retrieves Booking Details for a Given Date
	 * 
	 * @param date
	 *            : Date on which Booking Details are to be Retrieved
	 * @param model
	 *            : Contains List of Booking Details on a Specific Date
	 * @return
	 */
	@RequestMapping("/viewBookingsOnDateSpecified.htm")
	public String viewBookingsOnDateSpecified(@RequestParam("date") Date date,
			Model model) {
		List<BookingDetail> list = null;
		try {
			list = hotelService.viewBookingDetailsFromDate(date);
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (list.isEmpty())
			list = null;
		model.addAttribute("item", "hi");
		model.addAttribute("message", date);
		model.addAttribute("list", list);
		return "BookingDetailsByDate";
	}

	/**
	 * Retrieves Booking Details for a Hotel
	 * 
	 * @param hotelId
	 *            : Hotel ID of Hotel for which Booking Details are to be
	 *            Retrieved
	 * @param model
	 *            : Contains List of Booking Details for a Hotel
	 * @return
	 */
	@RequestMapping("/viewBookingsOfHotel")
	public String viewBookingsOfHotel(@RequestParam("hotelId") int hotelId,
			Model model) {
		List<Hotel> list = null;
		try {
			list = hotelService.viewAllHotels();
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (list.isEmpty())
			list = null;
		List<BookingDetail> list2 = null;
		try {
			list2 = hotelService.viewBookingSpecificHotel(hotelId);
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (list2.isEmpty()) {
			list2 = null;
			model.addAttribute("message", Constant.nRB);
		}
		model.addAttribute("hotelId", hotelId);
		model.addAttribute("list", list);
		model.addAttribute("list2", list2);
		return "HotelBookingDetails";
	}

	/**
	 * Retrieves Guest List of a Hotel
	 * 
	 * @param hotelId
	 *            : Hotel ID of a Hotel for which Guest List is to be Retrieved
	 * @param model
	 *            : Contains Guest List of the Hotel
	 * @return
	 */
	@RequestMapping("/viewGuestList.htm")
	public String viewGuestList(@RequestParam("hotelId") int hotelId,
			Model model) {
		List<Hotel> list = null;
		try {
			list = hotelService.viewAllHotels();
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (list.isEmpty())
			list = null;
		List<UserDetail> list2 = null;
		try {
			list2 = hotelService.viewGuestListSpecificHotels(hotelId);
		} catch (HotelManagementException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("list", list);
		model.addAttribute("list2", list2);
		model.addAttribute("hotelId", hotelId);
		return "HotelGuestList";
	}

}
