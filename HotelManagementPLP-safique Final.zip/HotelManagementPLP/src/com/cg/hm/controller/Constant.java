package com.cg.hm.controller;

/**
 * Constant Values
 * 
 * @author rohitaku
 *
 */
public interface Constant {
	 String ADMINID="System";
	    String ADMINPASS="Capgemini123";
	 String message = "message";
	 String message2 = "message2";
	 String iIP = "Invalid Id or Password!!!";
	 String hAS = "Hotel Added Successfully!!!";
	 String rAS = "Room Added Successfully!!!";
	 String nRA = "No Room Available in This Hotel";
	 String rDS = "Room Deleted Successfully!!!";
	 String hDS = "Hotel Deleted Successfully!!!";
	 String hMS = "Hotel Modified Successfully!!!";
	 String rMS = "Room Modified Successfully!!!";
	 String nRB = "No Room Booked in This Hotel";
	 String[] dropDownList = { "Select", "Standard non A/C room",
			"Standard A/C room", "Executive A/C room", "Deluxe A/C room" };
}
