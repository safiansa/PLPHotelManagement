package com.cg.hm.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="room_details")
public class RoomDetails implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="room_id")
	private Integer roomId;
	
	@NotNull
	@Column(name="hotel_id")
	private Integer hotelId;
	
	@Pattern(regexp="[1-9]{1}[0-9]{1,}",message="It should be a number")
	@Column(name="room_no")
	private String roomNo;
	
	@NotEmpty(message="Please Select any option")
	@Column(name="room_type")
	private String roomType;
	
	
	@Column(name="per_night_rate")
	@Min(1000)
	private Integer perNightRate;
	
	@Pattern(regexp="[A-Za-z]{1,}",message="Enter YES/NO")
	@Column(name="availability")
	private String availability;

	public RoomDetails(Integer hotelId, Integer roomId, String roomNo,
			String roomType, Integer perNightRate, String availability) {
		super();
		this.hotelId = hotelId;
		this.roomId = roomId;
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.perNightRate = perNightRate;
		this.availability = availability;
	}
	public RoomDetails() {
	}
	public Integer getHotelId() {
		return hotelId;
	}
	public void setHotelId(Integer hotelId) {
		this.hotelId = hotelId;
	}
	public Integer getRoomId() {
		return roomId;
	}
	public void setRoomId(Integer roomId) {
		this.roomId = roomId;
	}
	public String getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	public Integer getPerNightRate() {
		return perNightRate;
	}
	public void setPerNightRate(Integer perNightRate) {
		this.perNightRate = perNightRate;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	@Override
	public String toString() {
		return "roomDetails [hotelId=" + hotelId + ", roomId=" + roomId
				+ ", roomNo=" + roomNo + ", roomType=" + roomType
				+ ", perNightRate=" + perNightRate + ", availability="
				+ availability + "]";
	}
}

